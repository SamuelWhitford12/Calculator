﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

/* 
 * Author: Sam Whitford
 * Creation Date: 25/10/2018
 * Version: 1.0
 */ 
namespace Calculator
{
    public partial class Calculator : Form
    {
        public Calculator()
        {
            InitializeComponent();
        }
        //Is set to the value when an expression button is pressed
        double SavedTotal = 0;
        //The answer
        double Answer = 0;
        //Becomes true if any of the related buttons are pressed
        bool Plus = false;
        bool Minus = false;
        bool Divide = false;
        bool Multiply = false;

        #region Adding Characters
        //Following methods add numbers to the display
        private void btn1_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "1";
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "2";
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "3";
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "4";
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "5";
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "6";
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "7";
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "8";
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "9";
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "0";
        }

        private void btnDec_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += ".";
        }
        #endregion
        //Arithmetic methods
        private void btnPlus_Click(object sender, EventArgs e)
        {
            //Saves the current number in and sets what symbol to use
            SavedTotal += double.Parse(txtDisplay.Text);
            txtDisplay.Clear();
            Plus = true;
            Minus = false;
            Divide = false;
            Multiply = false;
        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            //Saves the current number in and sets what symbol to use
            SavedTotal += double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            Plus = false;
            Minus = true;
            Divide = false;
            Multiply = false;
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            //Saves the current number in and sets what symbol to use
            SavedTotal += double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            Plus = false;
            Minus = false;
            Divide = true;
            Multiply = false;
        }

        private void btnTimes_Click(object sender, EventArgs e)
        {
            //Saves the current number in and sets what symbol to use
            SavedTotal += double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            Plus = false;
            Minus = false;
            Divide = false;
            Multiply = true;
        }
        //Algebraic methods
        private void btnSQRT_Click(object sender, EventArgs e)
        {
            double Number = double.Parse(txtDisplay.Text);
            txtDisplay.Text = AlgebraicLibary.Algebra.SquareRoot(Number).ToString();

        }

        private void btnCubeRT_Click(object sender, EventArgs e)
        {
            double Number = double.Parse(txtDisplay.Text);
            txtDisplay.Text = AlgebraicLibary.Algebra.CubeRoot(Number).ToString();
        }
        private void btnInv_Click(object sender, EventArgs e)
        {
            //Adds a - to the number
            string Value = txtDisplay.Text;
            txtDisplay.Clear();
            txtDisplay.Text += AlgebraicLibary.Algebra.Inverse(Value);
        }
        //Trigonometric methods
        private void btnTan_Click(object sender, EventArgs e)
        {
            double Number = double.Parse(txtDisplay.Text);
            if (Number != 90)
            {
                txtDisplay.Text = TrigonometricLibary.Trigonometric.Tan(Number).ToString();
            }
            else if (Number == 90)
            {
                MessageBox.Show("Invalid Input", "Error Message");
                txtDisplay.Text = "0";
            }
        }

        private void btnSin_Click(object sender, EventArgs e)
        {
            double num = double.Parse(txtDisplay.Text);
            txtDisplay.Text = TrigonometricLibary.Trigonometric.Sin(num).ToString();
        }

        private void btnCos_Click(object sender, EventArgs e)
        {
            double num = double.Parse(txtDisplay.Text);
            txtDisplay.Text = TrigonometricLibary.Trigonometric.Cos(num).ToString();
        }
        //Other methods
        private void btnClear_Click(object sender, EventArgs e)
        {
            //Clears everything
            txtDisplay.Clear();
        }

        private void btnEqu_Click(object sender, EventArgs e)
        {
            //if any button is pressed
            //Plus
            if (Plus)
            {
                Answer = BasicMath.Arithmetic.Add(SavedTotal, double.Parse(txtDisplay.Text));
            }
            //Minus
            else if (Minus)
            {
                Answer = BasicMath.Arithmetic.Sub(SavedTotal, double.Parse(txtDisplay.Text));
            }
            //Divide
            else if (Divide)
            {
                Answer = BasicMath.Arithmetic.Div(SavedTotal, double.Parse(txtDisplay.Text));
            }
            //Multiply
            else if (Multiply)
            {
                Answer = BasicMath.Arithmetic.Mult(SavedTotal, double.Parse(txtDisplay.Text));
            }
            txtDisplay.Text = Answer.ToString();
            SavedTotal = 0;
        }


    }
}

